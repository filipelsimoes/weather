export const urlForSearch = "http://localhost:8081/weather?city=";
export const urlForSearchByCoords = "http://localhost:8081/find?lat="