import './App.css';
import Homepage from './screens/Homepage';

function App() {
  return (
    <div>
      <Homepage></Homepage>
    </div>
  );
}

export default App;
